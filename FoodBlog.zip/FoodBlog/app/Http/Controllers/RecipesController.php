<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Post;


class RecipesController extends Controller
{
    public function index()
    {
        $posts =DB::table('posts')
        ->join('users','posts.userid','=','users.id')
        ->select('posts.id','posts.title','posts.image','posts.created_at','users.name')
        ->orderBy('posts.created_at','DESC')->get();

        return view('recipes.index')->with('posts', $posts);
    }

    public function show($id)
    {
        $post = Post::find($id);
        return view('recipes.show')->with('post', $post);
    }

}
