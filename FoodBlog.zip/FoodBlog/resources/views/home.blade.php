@extends('layouts.app')

@section('content')

    <!-- Hero Section Begin -->
    <section class="hero">
            <div class="hero__slider owl-carousel">
                <div class="hero__item">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-6 p-0">
                                <div class="hero__inside__item hero__inside__item--wide set-bg"
                                    data-setbg="img/hero/hero-1.jpg">
                                    <div class="hero__inside__item__text">
                                        <div class="hero__inside__item--meta">
                                            <span>08</span>
                                            <p>Aug</p>
                                        </div>
                                        <div class="hero__inside__item--text">
                                            <ul class="label">
                                                <li>Vegan</li>
                                                <li>Desserts</li>
                                            </ul>
                                            <h4>Vegan White Peach Mug Cobbler With CardamomVegan<br /> White Peach Mug
                                                Cobbler With Cardamom</h4>
                                            <ul class="widget">
                                                <li>by <span>Admin</span></li>
                                                <li>3 min read</li>
                                                <li>20 Comment</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6  p-0">
                                <div class="hero__inside__item hero__inside__item--small set-bg"
                                    data-setbg="img/hero/hero-2.jpg">
                                    <div class="hero__inside__item__text">
                                        <div class="hero__inside__item--meta">
                                            <span>08</span>
                                            <p>Aug</p>
                                        </div>
                                        <div class="hero__inside__item--text">
                                            <ul class="label">
                                                <li>Vegan</li>
                                                <li>Desserts</li>
                                            </ul>
                                            <h5>How to Make a Milkshake With Any <br />Ice Cream, Any Toppings...</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="hero__inside__item hero__inside__item--small set-bg"
                                    data-setbg="img/hero/hero-3.jpg">
                                    <div class="hero__inside__item__text">
                                        <div class="hero__inside__item--meta">
                                            <span>08</span>
                                            <p>Aug</p>
                                        </div>
                                        <div class="hero__inside__item--text">
                                            <ul class="label">
                                                <li>Vegan</li>
                                                <li>Desserts</li>
                                            </ul>
                                            <h5>Vintage Copper Preserve Pan with <br />Brass Handles, Mid 19th Century</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6  p-0">
                                <div class="hero__inside__item set-bg" data-setbg="img/hero/hero-4.jpg">
                                    <div class="hero__inside__item__text">
                                        <div class="hero__inside__item--meta">
                                            <span>08</span>
                                            <p>Aug</p>
                                        </div>
                                        <div class="hero__inside__item--text">
                                            <ul class="label">
                                                <li>Vegan</li>
                                                <li>Desserts</li>
                                            </ul>
                                            <h5>Marinated Lentil Salad with Zucch <br />ini and Tomatoes</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="hero__item">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-6 p-0">
                                <div class="hero__inside__item hero__inside__item--wide set-bg"
                                    data-setbg="img/hero/hero-1.jpg">
                                    <div class="hero__inside__item__text">
                                        <div class="hero__inside__item--meta">
                                            <span>08</span>
                                            <p>Aug</p>
                                        </div>
                                        <div class="hero__inside__item--text">
                                            <ul class="label">
                                                <li>Vegan</li>
                                                <li>Desserts</li>
                                            </ul>
                                            <h4>Vegan White Peach Mug Cobbler With CardamomVegan<br /> White Peach Mug
                                                Cobbler With Cardamom</h4>
                                            <ul class="widget">
                                                <li>by <span>Admin</span></li>
                                                <li>3 min read</li>
                                                <li>20 Comment</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 p-0">
                                <div class="hero__inside__item hero__inside__item--small set-bg"
                                    data-setbg="img/hero/hero-3.jpg">
                                    <div class="hero__inside__item__text">
                                        <div class="hero__inside__item--meta">
                                            <span>08</span>
                                            <p>Aug</p>
                                        </div>
                                        <div class="hero__inside__item--text">
                                            <ul class="label">
                                                <li>Vegan</li>
                                                <li>Desserts</li>
                                            </ul>
                                            <h5>How to Make a Milkshake With Any <br />Ice Cream, Any Toppings...</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="hero__inside__item hero__inside__item--small set-bg"
                                    data-setbg="img/hero/hero-2.jpg">
                                    <div class="hero__inside__item__text">
                                        <div class="hero__inside__item--meta">
                                            <span>08</span>
                                            <p>Aug</p>
                                        </div>
                                        <div class="hero__inside__item--text">
                                            <ul class="label">
                                                <li>Vegan</li>
                                                <li>Desserts</li>
                                            </ul>
                                            <h5>Vintage Copper Preserve Pan with <br />Brass Handles, Mid 19th Century</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6 p-0">
                                <div class="hero__inside__item set-bg" data-setbg="img/hero/hero-4.jpg">
                                    <div class="hero__inside__item__text">
                                        <div class="hero__inside__item--meta">
                                            <span>08</span>
                                            <p>Aug</p>
                                        </div>
                                        <div class="hero__inside__item--text">
                                            <ul class="label">
                                                <li>Vegan</li>
                                                <li>Desserts</li>
                                            </ul>
                                            <h5>Marinated Lentil Salad with Zucch <br />ini and Tomatoes</h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Hero Section End -->

        <div class="container-fluid">
            <div class="footer__instagram">
               
                <div class="row">
                    <div class="col-lg-2 col-md-2 col-sm-4 col-6">
                        <div class="footer__instagram__item set-bg" data-setbg="img/footer/ip-1.jpg"></div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 col-6">
                        <div class="footer__instagram__item set-bg" data-setbg="img/footer/ip-2.jpg"></div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 col-6">
                        <div class="footer__instagram__item set-bg" data-setbg="img/footer/ip-3.jpg"></div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 col-6">
                        <div class="footer__instagram__item set-bg" data-setbg="img/footer/ip-4.jpg"></div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 col-6">
                        <div class="footer__instagram__item set-bg" data-setbg="img/footer/ip-5.jpg"></div>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 col-6">
                        <div class="footer__instagram__item set-bg" data-setbg="img/footer/ip-6.jpg"></div>
                    </div>
                </div>
            </div>
        </div>

@endsection
