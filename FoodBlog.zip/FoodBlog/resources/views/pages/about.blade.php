@extends('layouts.app')
@section('content')
      <!-- About Section Begin -->
    <section class="about spad">
        <div class="container">
            <div class="about__text">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="breadcrumb__text">
                            <h2>About me</h2>
                            <div class="breadcrumb__option">
                                <a href="#">Home</a>
                                <span>About</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="about__pic__item__large">
                            <img src="img/about/about-1.jpg" alt="">
                        </div>
                        <div class="about__pic">
                            <div class="about__pic__item">
                                <img src="img/about/about-2.jpg" alt="">
                            </div>
                            <div class="about__pic__item">
                                <img src="img/about/about-3.jpg" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="about__right__text">
                            <h2>Hello every one !!!</h2>
                            <p>This blog was created, specially for food lovers</p>
                            <ul>
                                <li>Find Recipes.</li>
                                <li>Post Recipes.</li>
                                
                            </ul>
                            <p>Share your favourite recipes with others, and get to learn knew recipes.
                                The extensive recipe collection, 
                                includes treats such as pancakes, a childhood favourite, as well as exciting
                                dinner ideas, perfect for entertaining guests or even when cooking for one.
                            </p>
                           
                                <p class="fa fa-envelope-o"> FoodLover@gmail.com</p>
                            
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- About Section End -->
   @endsection