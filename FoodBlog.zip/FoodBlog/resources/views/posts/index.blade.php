@extends('layouts.app')

@section('content')

<style>
  .container{
    display: grid;
    grid-template-columns: repeat(6, auto);
    grid-gap: 2px;
}

.card {
    margin: 0;
}
  </style>

<div class="container">
 <h2>Posts</h2>
</div>
<br/>
<div class="container">

 

      
       @if(count($posts) > 0)
      
       @foreach($posts as $post)
      
       <div class="container">
       
           <div class="card" style="width: 20rem;">
                <img class="card-img-top" style="width: 100%" src="./storage/images/{{$post->image}}" alt="Card image cap">
                <div class="card-body">
                    <h4 class="card-text">{{$post->title}}</h4>
                  <p class="card-text">Written on: {{$post->created_at}}</p>
                  <a href="./posts/{{$post->id}}" class="btn btn-primary">View Recipe</a>
                </div>
              </div>
            </div> 
        
             
   <br/>
       
      
       @endforeach
  
    @else
    <p>No posts found</p>

       @endif
</div>
   @endsection