
<?php $__env->startSection('content'); ?>

<style>
  .container{
    display: grid;
    grid-template-columns: repeat(6, auto);
    grid-gap: 2px;
}

.card {
    margin: 0;
}
  </style>
  <div class="container">
  <h2>Recipes</h2>
  </div>
  <br/>
<div class="container">

 

     
       <?php if(count($posts) > 0): ?>
      
       <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
       <div class="container">
           <div class="card" style="width: 20rem;">
                <img class="card-img-top"   style="width: 100%" src="./storage/images/<?php echo e($post->image); ?>" alt="Card image cap">
                <div class="card-body">
                    <h4 class="card-text"><?php echo e($post->title); ?></h4>
                  <p class="card-text">Written on: <?php echo e($post->created_at); ?></p>
                   <p class="card-text">Posted By: <?php echo e($post->name); ?> </p>
                  <a href="./recipes/<?php echo e($post->id); ?>" class="btn btn-primary">View Recipe</a>
                </div>
              </div> 
            </div>
   <br/>
       
      
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
    <?php else: ?>
    <p>No Recipes found</p>

       <?php endif; ?>
</div>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FoodBlog\resources\views/recipes/index.blade.php ENDPATH**/ ?>