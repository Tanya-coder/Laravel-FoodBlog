<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'FoodBlog')); ?></title>

  

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

   

     <!-- Google Font -->
     <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,600,700,800,900&display=swap"
     rel="stylesheet">
 <link href="https://fonts.googleapis.com/css?family=Unna:400,700&display=swap" rel="stylesheet">

 <!-- Css Styles -->
 <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
 <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
 <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
 <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
 <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
 <link rel="stylesheet" href="css/style.css" type="text/css">

 
</head>
<body>
        <div id="preloder">
                <div class="loader"></div>
            </div>
    
   <div id="app"> 
 

    <!-- Humberger Begin -->
    <div class="humberger__menu__overlay"></div>
    <div class="humberger__menu__wrapper">
        <div class="humberger__menu__logo">
            <a href="./"><img src="img/logc.png" alt=""></a>
        </div>
        <nav class="humberger__menu__nav mobile-menu">
            <ul>
                <li><a href="./">Home</a></li>
                <li><a href="./about">About</a></li>
                <li><a href="./contact">Contact</a></li>
                <?php if(Auth::guest()): ?>
                <li><a href="./login">Sign In</a></li>
                  <?php endif; ?>
                  <?php if(!Auth::guest()): ?>
                  <li><a href="./posts">Blog</a></li>
                  <li><a href="./posts/create">Post</a></li>
                  <?php endif; ?>
                
               
            </ul>
        </nav>
        <div id="mobile-menu-wrap"></div>
        <div class="humberger__menu__about">
           
            <img src="img/humberger/humberger-about.jpg" alt="">
            <h6>Hi every one! I'm Tanya.</h6>
            <p>Welcome to Food Lovers Blog, Find recipes, Post recipes and more ...</p>
          
        </div>
        <div style= "color: pink:" class="humberger__menu__subscribe">
            <div class="humberger__menu__title sidebar__item__title" style= "color: pink:">
                <h6 style= "color:pink">Subscribe</h6>
            </div>
            <p>Subscribe to our newsletter and get our newest updates right on your inbox.</p>
            <form action="#">
                <input type="text" class="email-input" placeholder="Your email">
                <label for="agree-check">
                    I agree to the terms & conditions
                    <input type="checkbox" id="agree-check">
                    <span class="checkmark" style="color:pink;"></span>
                </label>
                <button type="submit" class="site-btn" style="background-color: pink; color:black">Subscribe</button>
            </form>
        </div>
    </div>
    <!-- Humberger End -->

    <!-- Header Section Begin -->
    <header class="header">
            <div class="header__top">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2 col-md-1 col-6 order-md-1 order-1">
                            <div class="header__humberger">
                                <i class="fa fa-bars humberger__open"></i>
                            </div>
                        </div>
                        <div class="col-lg-8 col-md-10 order-md-2 order-3">
                            <nav class="header__menu">
                                 
                                <ul>
                                    <li class="active"><a href="./">Home</a></li>
                                    <li><a href="./recipes">Recipes</a>
                                      
                                        
                                    </li>
                                   
                            
                                    <li><a href="./about">About</a></li>
                                   
                                    <?php if(!Auth::guest()): ?>
                                    <li><a href="./posts">blog</a></li>
                                    <?php endif; ?>
                                    <li><a href="./posts/create">Post</a></li>
                                </ul>
                            
                        </div>
                    </nav>
                        <div class="col-lg-2 col-md-1 col-6 order-md-3 order-2">
                             <!-- Authentication Links -->
                             <ul class="navbar-nav ml-auto">
                        <?php if(auth()->guard()->guest()): ?>
                        <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Sign In')); ?></a>
                        </li>
                       
                           
                        <?php endif; ?>
                    <?php else: ?>
                    
                    

                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>
                    </ul>
                        </div>
                       
                    </div>
                 
                </div>
            </div>
       
            <div class="container">
                <div class="row">
                   
                    <div class="col-lg-3 col-md-3">
                        <?php if(Auth::guest()): ?>
                        <div class="header__btn">
                            <a href="./register" class="primary-btn">Register</a>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-lg-6 col-md-6">
                        <div class="header__logo">
                            <a href="./"><img src="img/logc.png" alt=""></a>
                        </div>
                    </div>
                  
                </div>
            </div>
        </header>
        <!-- Header Section End -->



       

        <main class="py-4"> 
            <?php echo $__env->yieldContent('content'); ?>
        </main>


        <!-- Footer Section Begin -->
    <footer class="footer">
       
        
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer__text">
                        <div class="footer__logo">
                            <a href="#"><img src="img/logc.png" alt=""></a>
                        </div>
                        <p>Food Lovers Blog, For people who love and enjoy food
                            <br /><i class="fa fa-envelope-o"></i> FoodLoverBlog@gmail.com.
                            </p>
                       
                    </div>
                    <div class="footer__copyright">
                        <p>
                            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This Blog is made with <i class="fa fa-heart" aria-hidden="true"></i> by Tanya.
  <!-- Got template from https://colorlib.com --></p>
                    </div>
                </div>
            </div>
        
    </footer>
    <!-- Footer Section End -->


   </div>
       <!-- Js Plugins -->
       <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
     
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
       <script src="js/jquery-3.3.1.min.js"></script>
       <script src="js/bootstrap.min.js"></script>
       <script src="js/jquery.slicknav.js"></script>
       <script src="js/owl.carousel.min.js"></script>
       <script src="js/main.js"></script> 

       
</body>
</html>
<?php /**PATH C:\xampp\htdocs\FoodBlog\resources\views/layouts/app.blade.php ENDPATH**/ ?>